/**
 * Caijiajia confidential
 * 
 * Copyright (C) 2016 Shanghai Shuhe Co., Ltd. All rights reserved.
 * 
 * No parts of this file may be reproduced or transmitted in any form or by any means,
 * electronic, mechanical, photocopying, recording, or otherwise, without prior written
 * permission of Shanghai Shuhe Co., Ltd. 
 */
package cn.caijiajia.trainingproject.form;

import org.hibernate.validator.constraints.NotBlank;

/**
 * @author Elliott
 *
 */
public class CreateFundForm {
	
	@NotBlank(message="fundCode cannot be blank.")
	private String fundCode;
	
	@NotBlank(message="fundName cannot be blank.")
	private String fundName;
	
	// TODO: adds more fields

	public String getFundCode() {
		return fundCode;
	}

	public void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}

	public String getFundName() {
		return fundName;
	}

	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

}
