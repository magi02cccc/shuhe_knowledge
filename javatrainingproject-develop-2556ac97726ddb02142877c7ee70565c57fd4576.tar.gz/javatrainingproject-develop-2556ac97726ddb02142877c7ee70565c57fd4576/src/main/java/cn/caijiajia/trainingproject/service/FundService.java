/**
 * Caijiajia confidential
 * 
 * Copyright (C) 2016 Shanghai Shuhe Co., Ltd. All rights reserved.
 * 
 * No parts of this file may be reproduced or transmitted in any form or by any means,
 * electronic, mechanical, photocopying, recording, or otherwise, without prior written
 * permission of Shanghai Shuhe Co., Ltd. 
 */
package cn.caijiajia.trainingproject.service;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;

import cn.caijiajia.framework.exceptions.CjjServerException;
import cn.caijiajia.trainingproject.constant.ErrorCodes;
import cn.caijiajia.trainingproject.constant.ErrorMsgs;
import cn.caijiajia.trainingproject.form.CreateFundForm;

/**
 * @author Elliott
 *
 */
@Service
public class FundService {
	
	private static Logger logger = LoggerFactory.getLogger(FundService.class);
	
	/**
	 * xxxx
	 * @param form
	 * @return
	 */
	public Map<String, Object> createFund(CreateFundForm form) {
		Map<String, Object> result = Maps.newHashMap();
		
		try {
			// TODO: biz logic
		} catch (Exception e) {
			// TODO: 请按照实际情况更正下列异常处理
			logger.error("xxxx", e);
			throw new CjjServerException(ErrorCodes.ERR_COMMON_ERROR, ErrorMsgs.ERR_COMMON_ERROR);
		}
		
		return result;
	}
	
	// TODO
}
