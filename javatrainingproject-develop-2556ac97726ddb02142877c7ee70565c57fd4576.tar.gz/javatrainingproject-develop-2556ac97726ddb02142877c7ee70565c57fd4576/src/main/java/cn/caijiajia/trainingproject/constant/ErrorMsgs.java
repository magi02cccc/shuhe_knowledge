/**
 * Caijiajia confidential
 * 
 * Copyright (C) 2015 Shanghai Shuhe Co., Ltd. All rights reserved.
 * 
 * No parts of this file may be reproduced or transmitted in any form or by any means,
 * electronic, mechanical, photocopying, recording, or otherwise, without prior written
 * permission of Shanghai Shuhe Co., Ltd. 
 */
package cn.caijiajia.trainingproject.constant;

/**
 * @author Elliott
 *
 */
public class ErrorMsgs {
	
	public static final String ERR_COMMON_ERROR = "未知异常";

}
