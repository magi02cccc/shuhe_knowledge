/**
 * Caijiajia confidential
 * 
 * Copyright (C) 2016 Shanghai Shuhe Co., Ltd. All rights reserved.
 * 
 * No parts of this file may be reproduced or transmitted in any form or by any means,
 * electronic, mechanical, photocopying, recording, or otherwise, without prior written
 * permission of Shanghai Shuhe Co., Ltd. 
 */
package cn.caijiajia.trainingproject.domain;

/**
 * @author Elliotts
 *
 */
public class Fund {
	
	private String id;
	private String fundCode;
	private String fundName;

	//TODO: add more fields
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public String getFundCode() {
		return fundCode;
	}

	public void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}

	public String getFundName() {
		return fundName;
	}

	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

}
