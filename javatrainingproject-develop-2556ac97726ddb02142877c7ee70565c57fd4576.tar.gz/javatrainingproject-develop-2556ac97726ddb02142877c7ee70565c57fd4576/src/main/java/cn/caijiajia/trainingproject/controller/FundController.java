/**
 * Caijiajia confidential
 * 
 * Copyright (C) 2015 Shanghai Shuhe Co., Ltd. All rights reserved.
 * 
 * No parts of this file may be reproduced or transmitted in any form or by any means,
 * electronic, mechanical, photocopying, recording, or otherwise, without prior written
 * permission of Shanghai Shuhe Co., Ltd. 
 */
package cn.caijiajia.trainingproject.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import cn.caijiajia.trainingproject.form.CreateFundForm;
import cn.caijiajia.trainingproject.service.FundService;

/**
 * @author Elliott
 *
 */
@RestController
public class FundController {
	
	@Autowired
	private FundService fundService;
	
	/**
	 * xxxxx
	 * @param form
	 * @return
	 */
    @RequestMapping(value = "/funds", method = RequestMethod.POST)
	public Map<String, Object> createFund(@RequestBody @Valid CreateFundForm form) {
		
    	//TODO: validation and so on...
    	return fundService.createFund(form);
	}
    
    // TODO
}
